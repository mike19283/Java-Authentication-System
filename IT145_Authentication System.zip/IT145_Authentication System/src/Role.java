import java.io.*;
import java.util.*;

public class Role {
    // Declare our dictionary (map)
    private Map<String,String> roles;
    // Our constructor. This only fires once on creation
    public Role () throws FileNotFoundException {
        // Initiate our Map
        roles = new HashMap<>();
        // This gets the directory we need
        File file = new File("src/");
        // Create an array of all the file paths in the directery
        String [] allPaths = file.list();
        //Create a list because there are not always the same number.
        List <String> textFiles = new ArrayList<>();
        // Loop through the list to find the txt files
        // I'm positive it could be done better, but this works and doesn't require Google
        for (String allPath : allPaths) {
            // Check if it ends in .txt AND that it's != to user
            if (allPath.endsWith(".txt") == true && !allPath.equals("users.txt")) {
                // If so, add to our text file array
                textFiles.add(allPath);
            }
        }
        for (int i = 0; i < textFiles.size(); i++) {
            /* Receives the path of the current file
             * Receives the wholle file as just one long string
             * Receives the first line so we can deduce the role
            */
            String currentPath = textFiles.get(i),
                  fileAsString = "";
            // Create a null scanner IF we find something
            Scanner scnr = null;

            // try..catch are always used to read files
            try 
            {
                // First, load the file
                scnr = new Scanner(new File("src/" + currentPath));
                // We keep adding lines while it has a next line
                for (int j = 0; scnr.hasNextLine(); j++) {
                    fileAsString += scnr.nextLine() + "\n";
                }
                // Close all files when done.
                scnr.close();
                // Split on ., making an array, and grab the 1st (0) element
                String fileName = textFiles.get(i).split("\\.")[0];
                // Add file contents to our dictionary for validation later
                roles.put(fileName, fileAsString);

                // We caught an error!
            } catch(FileNotFoundException e) {
                // This is what the error code is
                System.out.println("Exception occured" + e);
            } 
        }
    } 
    
    public String getRoleInfo(String userRole) {
        // Given a role, return the text from the file of the role
        return roles.get(userRole);
    }
    
}