import java.io.*;
import java.security.*;
import java.util.*;

public class User {
    // Our dictionary for later
    private Map<String,String> usernameInformation;
    // Constructor
    public User() throws FileNotFoundException {
        // We initialize our dictionary
        usernameInformation = new HashMap<>();
                
        // Use try..catch since we are working with files
        try {
            // First, load the file
            Scanner scnr = new Scanner(new File("src/Users.txt"));
            while (scnr.hasNext()) {
                // Get next line of file to work on
                String newLine = scnr.nextLine();
                String arr[] = newLine.split("\t");
                
                // array is 0, 1, 2, 3
                // 0 and 1 are username and hashed password,
                // 2 is for testing
                // 3 is role
                usernameInformation.put(arr[0] + arr[1], arr[3]); 
                
            }
            
        // We caught an error!
        } catch(FileNotFoundException e) {
            // This is what the error code is
            System.out.println("Exception occured" + e);
        }
    }
    // Return the value the key corresponds to
    public String getRole (String user_and_pass) {
        return usernameInformation.get(user_and_pass);
    }
    //Get MD5 Hash
    public String getMD5Hash (String original) throws NoSuchAlgorithmException {
        //Copy and paste this section of code
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(original.getBytes());
        byte[] digest = md.digest();
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
                sb.append(String.format("%02x", b & 0xff));
        }
        //End copy/paste
	return sb.toString();
    }
    
}
